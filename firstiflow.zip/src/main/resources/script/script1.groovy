import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant

Message processData(Message message) {
    java.io.Reader reader = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(reader)

    String rawEmail = (json.email ?: "") as String
    String maskedEmail = maskEmail(rawEmail)

    // Overwrite the PII in place — do not carry the raw email forward.
    json.email = maskedEmail
    json.processedTimestamp = Instant.now().toString() // e.g. 2026-09-21T10:00:00.123Z

    message.setProperty("p_customerCountry", (json.country ?: "") as String)

    message.setBody(JsonOutput.toJson(json))
    return message
}

static String maskEmail(String email) {
    if (!email) return ""
    int at = email.indexOf("@")
    if (at <= 0) return "***"
    String local = email.substring(0, at)
    String domain = email.substring(at + 1)
    String first = local.substring(0, 1)
    return "${first}***@${domain}"
}
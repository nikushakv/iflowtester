<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" indent="yes" encoding="UTF-8"/>

  <xsl:template match="/">
    <CustomerRecord>
      <ID><xsl:value-of select="//*[local-name()='customerId']"/></ID>
      <FullName>
        <xsl:value-of select="concat(//*[local-name()='firstName'], ' ', //*[local-name()='lastName'])"/>
      </FullName>
      <EmailMasked><xsl:value-of select="//*[local-name()='emailMasked']"/></EmailMasked>
      <Region><xsl:value-of select="//*[local-name()='country']"/></Region>
      <Status><xsl:value-of select="//*[local-name()='status']"/></Status>
      <ProcessedAt><xsl:value-of select="//*[local-name()='processedTimestamp']"/></ProcessedAt>
    </CustomerRecord>
  </xsl:template>

</xsl:stylesheet>